export interface IListColumn {
    Title: string;
    StaticName: string;
    TypeDisplayName: string;
}
//# sourceMappingURL=IListColumn.d.ts.map