import { IListService } from '../services/IListService';
import { IList } from '../services/IList';
import { IListColumn } from '../services/IListColumn';
import { IWebPartContext } from '@microsoft/sp-webpart-base';
export declare class ListService implements IListService {
    private context;
    constructor(context: IWebPartContext);
    getLists(): Promise<IList[]>;
    getColumns(listName: string): Promise<IListColumn[]>;
}
//# sourceMappingURL=ListService.d.ts.map