import { IPropertyPaneCustomFieldProps, IPropertyPaneField, PropertyPaneFieldType } from '@microsoft/sp-webpart-base';
export interface IItemProp {
    key: string;
    text: string;
}
export interface IMultiSelectProp {
    label: string;
    selectedItemIds?: string[];
    onload: () => Promise<IItemProp[]>;
    onPropChange: (targetProperty: string, oldValue: any, newValue: any) => void;
    properties: any;
    key?: string;
    disabled: boolean;
}
export interface IMultiSelectPropInternal extends IPropertyPaneCustomFieldProps {
    targetProperty: string;
    label: string;
    selectedItemIds?: string[];
    onload: () => Promise<IItemProp[]>;
    onPropChange: (targetPropery: string, oldValue: any, newValue: any) => void;
    onRender: (elem: HTMLElement) => void;
    onDispose: (elem: HTMLElement) => void;
    properties: any;
    selectedKey: string;
    disabled: boolean;
}
export declare class MultiSelectBuilder implements IPropertyPaneField<IMultiSelectPropInternal> {
    type: PropertyPaneFieldType;
    targetProperty: string;
    properties: IMultiSelectPropInternal;
    private label;
    private selectedItemIds;
    private onLoad;
    private onPropChange;
    private key;
    private cumstomProperties;
    private disabled;
    constructor(targetProperty: string, prop: IMultiSelectPropInternal);
    render(elem: HTMLElement, ctx?: any, changeCallback?: (targetProperty: string, oldValue: any, newValue: any) => void): void;
    private dispose;
}
export declare function PropertyPaneMultiSelect(targetProperty: string, properties: IMultiSelectProp): IPropertyPaneField<IMultiSelectPropInternal>;
//# sourceMappingURL=PropertyPaneMultiSelect.d.ts.map