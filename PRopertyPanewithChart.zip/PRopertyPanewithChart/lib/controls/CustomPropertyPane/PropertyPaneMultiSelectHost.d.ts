import * as React from 'react';
import { IItemProp, IMultiSelectPropInternal } from './PropertyPaneMultiSelect';
export interface IMultiSelectHostProp extends IMultiSelectPropInternal {
    stateKey: string;
}
export interface IMultiSelectHostState {
    items?: IItemProp[];
    selectedItems: string[];
}
export declare class MultiSelectHost extends React.Component<IMultiSelectHostProp, IMultiSelectHostState> {
    constructor(props: IMultiSelectHostProp, state: IMultiSelectHostState);
    componentDidMount(): void;
    componentDidUpdate(prevProps: IMultiSelectHostProp, prevState: IMultiSelectHostState): void;
    private loadOptions;
    private _applyMultiSelect;
    private getAllItems;
    private onClick;
    private getSelectedNodePosition;
    render(): JSX.Element;
}
//# sourceMappingURL=PropertyPaneMultiSelectHost.d.ts.map