import { IPropertyPaneField, PropertyPaneFieldType } from '@microsoft/sp-property-pane';
import { IPropertyPaneAsyncDropdownProps } from './IPropertyPaneAsyncDropdownProps';
import { IPropertyPaneAsyncDropdownInternalProps } from './IPropertyPaneAsyncDropdownInternalProps';
export declare class PropertyPaneAsyncDropdown implements IPropertyPaneField<IPropertyPaneAsyncDropdownProps> {
    type: PropertyPaneFieldType;
    targetProperty: string;
    properties: IPropertyPaneAsyncDropdownInternalProps;
    private elem;
    constructor(targetProperty: string, properties: IPropertyPaneAsyncDropdownProps);
    render(): void;
    private onDispose;
    private onRender;
    private onChanged;
}
//# sourceMappingURL=PropertyPaneAsyncDropdown.d.ts.map