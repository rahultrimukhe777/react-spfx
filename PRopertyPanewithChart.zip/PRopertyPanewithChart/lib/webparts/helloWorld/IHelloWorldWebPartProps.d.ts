import { IItemProp } from "./IItemProp";
import { SPHttpClient } from "@microsoft/sp-http";
export interface IHelloWorldWebPartProps {
    selectedColumnsAndType: IItemProp[];
    selectedIds: string[];
    listName: string;
    list: string;
    spHttpClient: SPHttpClient;
    pageSize?: number;
    selectedColumns: IItemProp[];
    siteUrl: string;
    SelectedColumns: string;
    ChartType: string;
}
//# sourceMappingURL=IHelloWorldWebPartProps.d.ts.map