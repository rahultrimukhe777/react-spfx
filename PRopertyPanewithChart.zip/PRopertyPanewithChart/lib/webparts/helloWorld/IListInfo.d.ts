export interface IListInfo {
    Id: string;
    Title: string;
}
//# sourceMappingURL=IListInfo.d.ts.map