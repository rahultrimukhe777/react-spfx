import * as React from 'react';
import { IHelloWorldProps } from './IHelloWorldProps';
import { IColumn } from 'office-ui-fabric-react/lib/DetailsList';
export interface IHelloWorldState {
    items?: any[];
    columns?: IColumn[];
    status?: string;
    currentPage?: number;
    itemCount?: number;
    pageSize?: number;
}
export default class HelloWorld extends React.Component<IHelloWorldProps, IHelloWorldState> {
    private selectQuery;
    private expandQuery;
    constructor(props: IHelloWorldProps);
    componentWillReceiveProps(nextProps: IHelloWorldProps): void;
    private getChart;
    render(): React.ReactElement<IHelloWorldProps>;
    private _onPageUpdate;
    private readItems;
    private buildQueryParams;
    private getListItemsCount;
    private buildColumns;
    private _onColumnClick;
    private countEntries;
}
//# sourceMappingURL=HelloWorld.d.ts.map