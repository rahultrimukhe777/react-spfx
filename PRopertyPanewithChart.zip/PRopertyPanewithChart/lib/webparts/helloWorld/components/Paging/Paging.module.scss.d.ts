declare const styles: {
    paginationContainer: string;
    searchWp__paginationContainer__pagination: string;
    active: string;
};
export default styles;
//# sourceMappingURL=Paging.module.scss.d.ts.map