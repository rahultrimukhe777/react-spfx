import * as React from 'react';
export interface IDCLabelProps {
    ListData?: any;
}
export declare class PieChart extends React.Component<IDCLabelProps, {}> {
    render(): React.ReactElement<IDCLabelProps>;
}
export declare class ScatterChart extends React.Component<IDCLabelProps, {}> {
    render(): React.ReactElement<IDCLabelProps>;
}
export declare class BarChart extends React.Component<IDCLabelProps, {}> {
    render(): React.ReactElement<IDCLabelProps>;
}
//# sourceMappingURL=Charts.d.ts.map