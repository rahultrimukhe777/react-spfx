import { IItemProp } from "../IItemProp";
import { SPHttpClient } from "@microsoft/sp-http";
export interface IHelloWorldProps {
    spHttpClient: SPHttpClient;
    listName: string;
    list: string;
    selectedIds: string[];
    pageSize?: number;
    selectedColumns: IItemProp[];
    siteUrl: string;
    SelectedColumn: string;
    ChartType: string;
}
//# sourceMappingURL=IHelloWorldProps.d.ts.map