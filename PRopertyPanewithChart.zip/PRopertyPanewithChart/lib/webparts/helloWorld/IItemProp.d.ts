export interface IItemProp {
    key: string;
    text: string;
}
export interface IMultiSelectProp {
    label: string;
    selectedItemIds?: string[];
    onload: () => Promise<IItemProp[]>;
    onPropChange: (targetProperty: string, oldValue: any, newValue: any) => void;
    properties: any;
    key?: string;
    disabled: boolean;
}
//# sourceMappingURL=IItemProp.d.ts.map