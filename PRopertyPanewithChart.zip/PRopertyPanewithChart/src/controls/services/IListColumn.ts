export interface IListColumn {
  Title: string;
  StaticName: string;
  TypeDisplayName: string;
}