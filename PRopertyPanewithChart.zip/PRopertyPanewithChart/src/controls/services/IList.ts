export interface IList {
  Id: string;
  Title: string;
}