import * as React from 'react';
import { Chart } from "react-google-charts";

export interface IDCLabelProps {
  ListData? : any;
}

const levelData = [['Eat', 2],['Commute', 2],['Watch TV', 2],['Sleep', 7],['Work', 11],['Eat', 2],['Commute', 2],['Watch TV', 2],['Sleep', 7],['Work', 11],['Eat', 2],['Commute', 2],['Watch TV', 2],['Sleep', 7]];

export class PieChart extends React.Component<IDCLabelProps,{}> {
    public render(): React.ReactElement<IDCLabelProps> {
        return (
          <Chart
            chartType="PieChart"
            data={this.props.ListData}
            options={{
              title: "",
              pieHole: 0.5,
              slices: [
                {color: "#3366CC"},{color: "#DC3912"},{color: "#FF9900"},
                {color: "#109618"},{color: "#990099"},{color: "#3B3EAC"},
                {color: "#0099C6"},{color: "#DD4477"},{color: "#66AA00"},
                {color: "#B82E2E"},{color: "#316395"},{color: "#994499"},
                {color: "#22AA99"},{color: "#AAAA11"},{color: "#6633CC"},
                {color: "#E67300"},{color: "#8B0707"},{color: "#329262"},
                {color: "#5574A6"},{color: "#3B3EAC"},{color: "#2BB673"},
                {color: "#d91e48"},{color: "#007fad"},{color: "#e9a227"}
              ],
              legend: {
                position: "right",
                alignment: "center",
                textStyle: {
                  color: "233238",
                  fontSize: 14
                }
              },
              tooltip: {
                showColorCode: true
              },
              chartArea: {
                left: 20,
                top: 20,
                width: "100%",
                height: "100%"
              },
              fontName: "Roboto"
            }}
            loader={<div>Loading Chart</div>}
            width="100%"
            height="400px"
            chartEvents={[{
              eventName: "select",
              callback({ chartWrapper }) {
                console.log("Selected ", chartWrapper.getChart().getSelection());
              }
            }]}
            rootProps={{ 'data-testid': '2' }}
          />
        );
    }
}


export class ScatterChart extends React.Component<IDCLabelProps,{}> {
  public render(): React.ReactElement<IDCLabelProps> {
      return (
        <Chart
        chartType="ScatterChart"
        data={[
          ["age", "weight"],
          [8, 12],
          [4, 5.5],
          [11, 14],
          [4, 5],
          [3, 3.5],
          [6.5, 7]
        ]}

        options={{title: "Age vs. Weight comparison",
          hAxis: { title: "Age"},
          vAxis: { title: "Weight"},
          chartArea: { left: 50, top: 10, width: '100%', height: '80%' },
          bar: { groupWidth: '100%' },
          legend: "none"}
        }
        width="100%"
        height="400px"
        chartEvents={[
          {
            eventName: "select",
            callback({ chartWrapper }) {
              alert(chartWrapper.getChart().getSelection());
            }
          }
        ]}
        />
      );
  }
}

export class BarChart extends React.Component<IDCLabelProps,{}> {
  public render(): React.ReactElement<IDCLabelProps> {
      return (
        <Chart
          chartType="ColumnChart"
          width="100%"
          data={[
            ['Task', 'Hours per Day','Test'],
            ['Work', 11, 15],
            ['Eat', 2, 5],
            ['Commute', 2, 9],
            ['Watch TV', 2, 17],
            ['Sleep', 7, 17],
          ]}
          
          options={
            {
              title: "Age vs. Weight comparison",
              hAxis: { title: "Age"},
              vAxis: { title: "Weight"},
              bar: { groupWidth: '40%' }
            }
          }
          
          rootProps={{ 'data-testid': '2' }}
          chartEvents={[
            {
              eventName: "select",
              callback({ chartWrapper }) {
                alert(chartWrapper.getChart().getSelection());
              }
            }
          ]}
        />
      );
  }
}
