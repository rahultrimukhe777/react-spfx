/* tslint:disable */
require("./Paging.module.css");
const styles = {
  paginationContainer: 'paginationContainer_15c8b071',
  searchWp__paginationContainer__pagination: 'searchWp__paginationContainer__pagination_15c8b071',
  active: 'active_15c8b071'
};

export default styles;
/* tslint:enable */