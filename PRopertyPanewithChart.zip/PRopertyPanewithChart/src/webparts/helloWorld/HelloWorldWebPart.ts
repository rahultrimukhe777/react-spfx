import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneChoiceGroup,
  IPropertyPaneChoiceGroupOption
} from '@microsoft/sp-webpart-base';

import * as strings from 'HelloWorldWebPartStrings';
import HelloWorld from './components/HelloWorld';
import { IHelloWorldProps } from './components/IHelloWorldProps';
import { IHelloWorldWebPartProps } from './IHelloWorldWebPartProps';
import { PropertyPaneAsyncDropdown } from '../../controls/PropertyPaneAsyncDropdown/PropertyPaneAsyncDropdown';
import { IDropdownOption } from 'office-ui-fabric-react/lib/components/Dropdown';
import { update, get } from '@microsoft/sp-lodash-subset';
import { ListService } from '../../controls/services/ListService';
import { IList } from '../../controls/services/IList';
import { IItemProp } from './IItemProp';
import { IListColumn } from '../../controls/services/IListColumn';
import { PropertyPaneMultiSelect } from '../../controls/CustomPropertyPane/PropertyPaneMultiSelect';
import { ScatterChart } from './components/Charts/Charts';


export default class HelloWorldWebPart extends BaseClientSideWebPart<IHelloWorldWebPartProps> {
  private lists: IDropdownOption[];
  protected onInit(): Promise<void> { 
    this.loadColumns = this.loadColumns.bind(this);
    this.selectedColumns = this.selectedColumns.bind(this);
    return super.onInit();
  }

  protected onPropertyPaneConfigurationStart(): void {

  }

  protected onPropertyPaneFieldChanged(propertyPath: string, oldValue: any, newValue: any): void {
    if (propertyPath === 'list' && newValue) {
      // push new list value
      super.onPropertyPaneFieldChanged(propertyPath, oldValue, newValue);
      // get previously selected column
      const previousItem: string[] = this.properties.selectedIds;
      // reset selected item
      this.properties.selectedIds = [];
      // push new item value
      this.onPropertyPaneFieldChanged('selectedIds', previousItem, this.properties.selectedIds);
      
      //this.columnsDropdown.render(this.domElement);

      this.render();
      // refresh the item selector control by repainting the property pane
      this.context.propertyPane.refresh();
      
    }
    else {
      super.onPropertyPaneFieldChanged(propertyPath, oldValue, newValue);
    }
  }

  public render(): void {
    const element: React.ReactElement<IHelloWorldProps > = React.createElement(
      HelloWorld,
      {
        listName: this.properties.listName,
        list: this.properties.list,
        selectedIds: this.properties.selectedIds,
        selectedColumns: this.selectedColumns(),
        spHttpClient: this.context.spHttpClient,
        siteUrl: this.context.pageContext.web.absoluteUrl,
        pageSize: this.properties.pageSize,
        SelectedColumn: this.properties.SelectedColumns,  
        ChartType: this.properties.ChartType
      }
    );
    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('listName', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneChoiceGroup('ChartType', { 
                  label: "Chart Type",
                  options: [{key: 'PieChart', text: 'Pie Chart'}, {key: 'BarChart', text: 'Bar Chart'}, {key: 'ScatterChart', text: 'Scatter Chart'} ]          
                }),
                new PropertyPaneAsyncDropdown('list', {
                  label: strings.DescriptionFieldLabel,
                  loadOptions: this.loadLists.bind(this),
                  onPropertyChange: this.onListChange.bind(this),
                  selectedKey: this.properties.list
                }),
                PropertyPaneMultiSelect("selectedIds", {
                  label: "Select Columns",
                  selectedItemIds: this.properties.selectedIds, //Ids of Selected Items
                  onload: () => this.loadColumns(), //On load function to items for drop down 
                  onPropChange: this.onPropertyPaneFieldChanged, // On Property Change function
                  properties: this.properties, //Web Part properties
                  key: "targetkey",  //unique key
                  disabled: !this.properties.list
                }),
                PropertyPaneChoiceGroup('SelectedColumns', { 
                  label: "Selected Columns",
                  options: this.properties.selectedIds.map((x)=>{
                    return {key: x, text: x}
                  })            
                })
              ]
            }
          ]
        }
      ]
    };
  }

  private loadLists(): Promise<IDropdownOption[]> {
    const dataService = new ListService(this.context);
    return new Promise<IDropdownOption[]>((resolve: (options: IDropdownOption[]) => void, reject: (error: any) => void) => {
      dataService.getLists()
      .then((response: IList[]) => {
        var options : any[] = [];
        response.forEach((item: IList) => {
          options.push({"key": item.Title, "text": item.Title});
        });
        resolve(options);
      });
    });
  }

  private loadColumns(): Promise<IItemProp[]> {
    if (!this.properties.list) {
      // resolve to empty options since no list has been selected
      return Promise.resolve();
    }
    const dataService = new ListService(this.context);

    return new Promise<IItemProp[]>(resolve => {
      dataService.getColumns(this.properties.list)
      .then((response) => {
          var options : IItemProp[] = [];
          this.properties.selectedColumnsAndType = [];
          response.forEach((column: IListColumn) => {
            options.push({"key": column.StaticName, "text": column.Title});
            this.properties.selectedColumnsAndType.push({"key": column.StaticName, "text": column.TypeDisplayName});
          });
          resolve(options);
          this.context.propertyPane.refresh();

      });
    });
    
  } 
  
  private selectedColumns(): IItemProp[] {
    if(this.properties.selectedColumnsAndType === null || 
      this.properties.selectedColumnsAndType===undefined || 
      this.properties.selectedColumnsAndType.length === 0){
      return [];
      }
      else{
        return this.properties.selectedColumnsAndType.filter(obj => this.properties.selectedIds.indexOf(obj.key) !== -1);
      }
  }

  private onListChange(propertyPath: string, newValue: any): void {
    const oldValue: any = get(this.properties, propertyPath);
    // store new value in web part properties
    if(oldValue!=newValue) {
      console.log("Its New List");
      update(this.properties, "selectedIds", (): any => { return []; });
    }
    
    update(this.properties, propertyPath, (): any => { return newValue; });
    this.loadColumns();
    // refresh web part
    this.render();
  }
}
