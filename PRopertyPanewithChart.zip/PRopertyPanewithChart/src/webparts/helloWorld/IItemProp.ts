export interface IItemProp {
    key: string;
    text: string;
}

export interface IMultiSelectProp {
    label: string; //Label
    selectedItemIds?: string[]; //Ids of Selected Items
    onload: () => Promise<IItemProp[]>; //On load function to items for drop down 
    onPropChange: (targetProperty: string, oldValue: any, newValue: any) => void; // On Property Change function
    properties: any; //Web Part properties
    key?: string;  //unique key
    disabled: boolean;
}