import * as $ from 'jquery';
const TopNavTiles = {
	MainNav: [
		{ Title : 'Home', Icon: 'fa fa-home' , ComponentName: 'Home'},
		{ Title : 'Forms', Icon: 'fa fa-file-word-o', ComponentName: 'Forms'},
		{ Title : 'About Us', Icon: 'fa fa-university', ComponentName: 'AboutUS'},
		{ Title : 'Welcome', Icon: 'fa fa-university', ComponentName: 'Welcome'}
	],
	NavTitle: 'Home'
};

export default (state = TopNavTiles, action) => {
    switch (action.type) {
      case 'TOP_NAV_CHANGE':
        if(action.NavTitle!=="Form")
          $('#navigation-bar').toggleClass('navbox-open');
        return {...state, NavTitle : action.NavTitle };
      default:
        return state;
    }
  };