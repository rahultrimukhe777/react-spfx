import { assign } from 'lodash';
const uuidv4 = require('uuid4');
const uuid4 = require('uuid4');
const FormInitialData = {
    FormPageTitle: '',
    FormCardIcon: '',
    EditFormIndex: -1,
    ActiveForm: {},
    ActiveSection: {},
    AddSectionBoxHidden: false,
    AddSubSectionBoxHidden: false,
    AddField: false,
    FormSwitch: true,
    FieldType: [{ ID: 'text', Value: 'Text' }, { ID: 'date', Value: 'Date' }, { ID: 'time', Value: 'Time'}, { ID: 'range', Value: 'Range'}, { ID: 'number', Value: 'Number'}, { ID: 'textarea', Value: 'Textarea' }, { ID: 'file', Value: 'File' }, { ID: 'dropdown', Value: 'Dropdown'}, { ID: 'checkbox', Value: 'Checkbox'}],
    NewFieldColumn: [
        { ID: 'FieldTitle', Type: 'text', LabelText: 'Field Title', LabelClass: 'FieldLabel', DefaultValue: '', InputClass: 'form-control', PlaceHolder: 'Enter new Field Title', SectionClass: 'col-lg-4 col-md-4 col-sm-12 col-xs-12 AddField', InputStyle: 'Verticle'},
        { ID: 'SectionTitle', Type: 'dropdown', LabelText: 'Section Title', LabelClass: 'FieldLabel', DefaultValue: '', InputClass: 'form-control', Options: [], SectionClass: 'col-lg-4 col-md-4 col-sm-12 col-xs-12 AddField', InputStyle: 'Verticle'},
        { ID: 'SubSectionTitle', Type: 'dropdown', LabelText: 'SubSection Title', LabelClass: 'FieldLabel', DefaultValue: '', InputClass: 'form-control', Options: [], SectionClass: 'col-lg-4 col-md-4 col-sm-12 col-xs-12 AddField', InputStyle: 'Verticle'},
        { ID: 'FieldType', Type: 'dropdown', LabelText: 'Field Type', LabelClass: 'FieldLabel', DefaultValue: '', InputClass: 'form-control', Options: [], SectionClass: 'col-lg-4 col-md-4 col-sm-12 col-xs-12 AddField', InputStyle: 'Verticle'},
        { ID: 'LabelText', Type: 'text', LabelText: 'Label Text', LabelClass: 'FieldLabel', DefaultValue: '', InputClass: 'form-control', PlaceHolder: 'Enter Label Text', SectionClass: 'col-lg-4 col-md-4 col-sm-12 col-xs-12 AddField', InputStyle: 'Verticle'},
        { ID: 'LabelClass', Type: 'text', LabelText: 'Label Class', LabelClass: 'FieldLabel', DefaultValue: '', InputClass: 'form-control', PlaceHolder: 'Enter Label Class',  DataList: { Title: 'ListLabelClass', Options: ['Test', 'Test2']}, SectionClass: 'col-lg-4 col-md-4 col-sm-12 col-xs-12 AddField', InputStyle: 'Verticle'},
        { ID: 'InputClass', Type: 'text', LabelText: 'Input Class', LabelClass: 'FieldLabel', DefaultValue: '', InputClass: 'form-control', PlaceHolder: 'Enter Input Class',  DataList: { Title: 'ListInputClass', Options: ['Test', 'Test2']}, SectionClass: 'col-lg-4 col-md-4 col-sm-12 col-xs-12 AddField', InputStyle: 'Verticle'},
        { ID: 'DefaultValue', Type: 'text', LabelText: 'Default Value', LabelClass: 'FieldLabel', DefaultValue: '', InputClass: 'form-control', PlaceHolder: 'Enter Default Text', SectionClass: 'col-lg-4 col-md-4 col-sm-12 col-xs-12 AddField', InputStyle: 'Verticle'},
        { ID: 'SectionClass', Type: 'text', LabelText: 'Section Class', LabelClass: 'FieldLabel', DefaultValue: '', InputClass: 'form-control', PlaceHolder: 'Enter Section Class',  DataList: { Title: 'ListSectionClass', Options: ['Test', 'Test2']}, SectionClass: 'col-lg-4 col-md-4 col-sm-12 col-xs-12 AddField', InputStyle: 'Verticle'}
    ],
    FormList: [
        { ID: 'Test 1', Title : 'Total Views'},
        { ID: 'Test 2', Title : 'Bugs Fixed'},
        { ID: 'Test 3', Title : 'Reports Submitted'},
        { ID: 'Test 4', Title : 'Profiles'},
        { ID: 'Test 5', Title : 'Total Views'},
        { ID: 'Test 6', Title : 'Bugs Fixed'},
        { ID: 'Test 7', Title : 'Reports Submitted'}
    ],
    SectionList: [
        { ID: 'Test 1', Title: 'Test Section 1', FormID: 'Test 1' },
        { ID: 'Test 2', Title: 'Test Section 2', FormID: 'Test 1' },
        { ID: 'Test 3', Title: 'Test Section 3', FormID: 'Test 1' },
        { ID: 'Test 4', Title: 'Test Section 4', FormID: 'Test 1' },
        { ID: 'Test 5', Title: 'Test Section 5', FormID: 'Test 2' },
        { ID: 'Test 6', Title: 'Test Section 6', FormID: 'Test 3' },
        { ID: 'Test 7', Title: 'Test Section 7', FormID: 'Test 4' }
    ],
    SubSectionList: [
        { ID: 'Test1', Title: 'Test Sub Section 1', SectionID: 'Test 1' },
        { ID: 'Test2', Title: 'Test Sub Section 2', SectionID: 'Test 1' },
        { ID: 'Test3', Title: 'Test Sub Section 3', SectionID: 'Test 1' },
        { ID: 'Test4', Title: 'Test Sub Section 4', SectionID: 'Test 1' },
        { ID: 'Test5', Title: 'Test Sub Section 5', SectionID: 'Test 2' },
        { ID: 'Test6', Title: 'Test Sub Section 6', SectionID: 'Test 3' },
        { ID: 'Test7', Title: 'Test Sub Section 7', SectionID: 'Test 4' }
    ],
    SubSectionFields: [
        { ID: 'Test1', SubSectionID: 'Test1', LabelText: "Box 1", LabelClass: "LabelClass", InputClass: "form-control newInputClass" , DefaultValue: "8888220748", Type: "text", SectionClass: "col-lg-4 col-md-4 col-xs-12 col-sm-12", Options: [] },
        { ID: 'Test2', SubSectionID: 'Test2', LabelText: "Box 2", LabelClass: "LabelClass", InputClass: "form-control newInputClass", DefaultValue: "8888220748", Type: "number", SectionClass: "col-lg-4 col-md-4 col-xs-12 col-sm-12", Options: [] },
        { ID: 'Test3', SubSectionID: 'Test3', LabelText: "Box 3", LabelClass: "LabelClass", InputClass: "form-control newInputClass", DefaultValue: "8888220748", Type: "textarea", SectionClass: "col-lg-4 col-md-4 col-xs-12 col-sm-12", Options: [] },
        { ID: 'Test4', SubSectionID: 'Test4', LabelText: "Box 4", LabelClass: "LabelClass", InputClass: "form-control newInputClass", DefaultValue: "8888220748", Type: "dropdown", SectionClass: "col-lg-4 col-md-4 col-xs-12 col-sm-12", Options: []},
        { ID: 'Test5', SubSectionID: 'Test1', LabelText: "Box 5", LabelClass: "LabelClass", InputClass: "form-control newInputClass" , DefaultValue: "8888220748", Type: "date", SectionClass: "col-lg-4 col-md-4 col-xs-12 col-sm-12", Options: [] },
        { ID: 'Test6', SubSectionID: 'Test2', LabelText: "Box 6", LabelClass: "LabelClass", InputClass: "form-control newInputClass", DefaultValue: "8888220748", Type: "file", SectionClass: "col-lg-4 col-md-4 col-xs-12 col-sm-12", Options: [] },
        { ID: 'Test7', SubSectionID: 'Test3', LabelText: "Box 7", LabelClass: "LabelClass", InputClass: "form-control newInputClass", DefaultValue: "8888220748", Type: "file", SectionClass: "col-lg-4 col-md-4 col-xs-12 col-sm-12", Options: [] },
        { ID: 'Test8', SubSectionID: 'Test4', LabelText: "Box 8", LabelClass: "LabelClass", InputClass: "form-control newInputClass", DefaultValue: "8888220748", Type: "number", SectionClass: "col-lg-4 col-md-4 col-xs-12 col-sm-12", Options: []},
        { ID: 'Test9', SubSectionID: 'Test1', LabelText: "Box 9", LabelClass: "LabelClass", InputClass: "form-control newInputClass" , DefaultValue: "8888220748", Type: "number", SectionClass: "col-lg-6 col-md-6 col-xs-12 col-sm-12", Options: [] },
        { ID: 'Test10', SubSectionID: 'Test2', LabelText: "Mobile", LabelClass: "LabelClass", InputClass: "form-control newInputClass", DefaultValue: "8888220748", Type: "number", SectionClass: "col-lg-6 col-md-6 col-xs-12 col-sm-12", Options: [] },
        { ID: 'Test11', SubSectionID: 'Test3', LabelText: "Mobile", LabelClass: "LabelClass", InputClass: "form-control newInputClass", DefaultValue: "8888220748", Type: "number", SectionClass: "col-lg-6 col-md-6 col-xs-12 col-sm-12", Options: [] },
        { ID: 'Test12', SubSectionID: 'Test4', LabelText: "Mobile", LabelClass: "LabelClass", InputClass: "form-control newInputClass", DefaultValue: "8888220748", Type: "number", SectionClass: "col-lg-6 col-md-6 col-xs-12 col-sm-12", Options: []}
    ]
};


export default (state:any = FormInitialData, action) => {
  switch (action.type) {
    case 'ADD_NEW_FORM':
        const ID = 'Form-'+ uuid4;
        return {
            ...state,
            FormList: [...state.FormList,{ID: ID, Title: 'Untitled'}],
            EditFormIndex: ID
        };

    case 'DELETE_FORM_BY_ID': 
        return {
            ...state,
            FormList: state.FormList.filter((x:any)=>x.ID!==action.ID)
        };

    case 'EDIT_FORM_BY_ID':
        return {
            ...state,
            EditFormIndex: action.ID
        };

    case 'RESET_FORM_EDIT_INDEX':
        return {
            ...state,
            EditFormIndex: -1
        };

    case 'UPDATE_FORM_TITLE':
        return {
            ...state,
            FormList: assign([], state.FormList, {[action.Index]: {
                ...state.FormList[action.Index],
                Title: action.Title
            }})
        };
    
    case 'SET_ACTIVE_FORM': 
        const ActiveSection = state.SectionList.find((x:any)=>x.FormID===action.ActiveForm.ID);
        return {
            ...state,
            ActiveForm: action.ActiveForm,
            ActiveSection: ActiveSection!==undefined ? ActiveSection : {}
        };

    case 'SET_ACTIVE_SECTION':
        return {
            ...state,
            ActiveSection: action.ActiveSection
        };

    case 'ADD_NEW_SECTION': 
        const SectionID = 'Section-'+ uuid4;
        return {
            ...state,
            SectionList: [...state.SectionList, { ID: SectionID, Title: action.NewSection, FormID: state.ActiveForm.ID } ],
            ActiveSection: { ID: SectionID, Title: action.NewSection, FormID: state.ActiveForm.ID },
            AddSectionBoxHidden: ! state.AddSectionBoxHidden
        };

    case 'ADD_NEW_SUB_SECTION':
        const SubSectionID = 'SubSection-' + uuid4;
        return {
            ...state,
            SubSectionList: [...state.SubSectionList, { ID: SubSectionID, Title: action.NewSubSection, SectionID: state.ActiveSection.ID }],
            AddSubSectionBoxHidden: false
        };

    case 'DELETE_SECTION':
        let FiltedSections = state.SectionList.filter((x)=>x.FormID===state.ActiveForm.ID);
        if(action.ID===state.ActiveSection.ID) {
            const Index = FiltedSections.indexOf(state.ActiveSection);
            const length = FiltedSections.length;
            let ActiveSection = {};
            if(length===1) {
                ActiveSection = {};
            } else if(Index===length-1){
                ActiveSection = FiltedSections[Index-1];
            } else {
                ActiveSection = FiltedSections[Index+1];
            }
            return {
                ...state,
                SectionList: FiltedSections.filter((x)=>x.ID !== action.ID),
                ActiveSection: ActiveSection
            };
        } else {
            return {
                ...state,
                SectionList: FiltedSections.filter((x)=>x.ID !== action.ID)
            };
        }
    
    case 'DELETE_SUB_SECTION': 
        return {
            ...state,
            SubSectionList: state.SubSectionList.filter((x)=>x.ID!==action.ID)
        };

    case 'ADD_SECTION_BOX_TOGGLE':
        return {
            ...state,
            AddSectionBoxHidden: ! state.AddSectionBoxHidden,
            AddSubSectionBoxHidden: false
        };
    
    case 'ADD_SUB_SECTION_BOX_TOGGLE':
        return {
            ...state,
            AddSubSectionBoxHidden: ! state.AddSubSectionBoxHidden,
            AddSectionBoxHidden: false
        };

    case 'ADD_FIELD_BOX_TOGGLE': 
        return {
            ...state,
            AddField: true
        };

    case 'FORM_SWITCH_TOGGLE': 
        return {
            ...state,
            FormSwitch: ! state.FormSwitch
        };

    case 'ON_CANCEL_CLICK':
        switch (action.target) {
            case "Section": 
                return {
                    ...state,
                    AddSectionBoxHidden: ! state.AddSectionBoxHidden
                };

            case "SubSection":
                return {
                    ...state,
                    AddSubSectionBoxHidden: ! state.AddSubSectionBoxHidden
                };
            case "Field":
                return {
                    ...state,
                    AddField: ! state.AddField
                };
        }
        break;
    case 'ON_DRAG_START':
        return {
            ...state,
            InputDragStart: action.Item
        };

    case 'ON_DRAG_OVER':
        return {
            ...state
        };

    case 'ON_DRAG_DROP': 
        console.log(action.Item);
        let updateArray = [];
        if(state.InputDragStart.SubSectionID!==action.Item.SubSectionID) {
            state.InputDragStart.SubSectionID=action.Item.SubSectionID;
        }
        const DropIndex = state.SubSectionFields.indexOf(action.Item);
        updateArray = state.SubSectionFields.filter((x)=>(x.ID!==state.InputDragStart.ID));
        updateArray.splice(DropIndex, 0, state.InputDragStart);
        return {
            ...state,
            SubSectionFields: updateArray
        };

    case 'ON_DRAG_DROP_EMPTY':
        if(action.SubSectionID!==state.InputDragStart.SubSectionID) {
            console.log(state.InputDragStart.SubSectionID,action.SubSectionID);
            state.InputDragStart.SubSectionID = action.SubSectionID;
            updateArray = state.SubSectionFields.filter((x)=>(x.ID!==state.InputDragStart.ID));
            updateArray.splice(0, 0, state.InputDragStart);
        }
        return {
            ...state,
            SubSectionFields: [...state.SubSectionFields,updateArray]
        };

    default:
      return state;

  }
};
  

