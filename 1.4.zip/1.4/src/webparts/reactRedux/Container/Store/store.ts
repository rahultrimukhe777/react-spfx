import { createStore, combineReducers, applyMiddleware, compose } from 'redux';
import NavTiles from './../Reducer/TopNavTile';
import FormData from './../Reducer/FormData';
import logger from 'redux-logger';
import thunk from 'redux-thunk';
import promise from 'redux-promise-middleware';
const composeEnhancers = window['__REDUX_DEVTOOLS_EXTENSION_COMPOSE__'] as typeof compose || compose;

const store = createStore(
    combineReducers(
        { 
            NavTiles,
            FormData
        }
    ),
    {},
    composeEnhancers(
        applyMiddleware( logger,
            thunk, 
            promise )
    )
);
export default store;