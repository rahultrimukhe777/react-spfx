declare interface IReactReduxWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ReactReduxWebPartStrings' {
  const strings: IReactReduxWebPartStrings;
  export = strings;
}
