/* tslint:disable */
require("./ReactRedux.module.css");
const styles = {
  reactRedux: 'reactRedux_4372bed9',
  container: 'container_4372bed9',
  row: 'row_4372bed9',
  column: 'column_4372bed9',
  'ms-Grid': 'ms-Grid_4372bed9',
  title: 'title_4372bed9',
  subTitle: 'subTitle_4372bed9',
  description: 'description_4372bed9',
  button: 'button_4372bed9',
  label: 'label_4372bed9'
};

export default styles;
/* tslint:enable */