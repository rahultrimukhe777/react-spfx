import * as React from 'react';
import styles from './ReactRedux.module.scss';
import Container from './Container';
import { IReactReduxProps } from './IReactReduxProps';
import { Provider } from 'react-redux';
import store from './../Container/Store/store';
import ContentBox from './ReactComponent/ContentBox';

export default class ReactRedux extends React.Component<IReactReduxProps, {}> {
  private states = store.getState();
  public componentDidMount(){
  }
  public render(): React.ReactElement<IReactReduxProps> {
    return (
      <div >
        <Provider store={store}>
          <Container>
            <ContentBox />
          </Container>
        </Provider>
      </div>
    );
  }
}
