import * as React from 'react';
import { connect } from 'react-redux';

const Home = (props) => {
    return (
        <div className=" FormContainer">
            This is Home
        </div>
    );
};

const mapStateToProps = (state) =>({
    NavTiles: state.NavTiles
});


export default connect(mapStateToProps)(Home);