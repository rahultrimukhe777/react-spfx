import * as React from 'react';
import { connect } from 'react-redux';
import Home from './Home/Home';
import Forms from './Forms/Forms';
import Form from './Forms/Form';

const getContentBox = (Choice: string) => {
    switch(Choice) {
        case 'Home':
            return <Home />;
        case 'Forms':
            return <Forms />;
        case 'Form':
            return <Form />;
        default: 
            return <p>Test Failed</p>;
    }
};

const ContentBox = (props) => {
    return (
        <div className="FormContainer">
            {getContentBox(props.NavTitle)}    
        </div>
    );
};

const mapStateToProps = (state) =>({
    NavTitle: state.NavTiles.NavTitle
});

export default connect(mapStateToProps)(ContentBox);