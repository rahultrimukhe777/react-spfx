import * as React from 'react';
import { connect } from 'react-redux';
import NavTileItem from './NavTileItem';
import { TopNavChange } from './TopNavActions';
import './__$NavTile.css';


const NavTile = (props) => {
    return (
        <div id="navigation-bar" className="navigation-bar">
            <div className="bar">
                <button id="navbox-trigger" className="navbox-trigger"><i className="fa fa-lg fa-th"></i></button>
                <h5 className="HeaderLabel">{props.NavTitle}</h5>
            </div>
            <div className="navbox">
                <div className="navbox-tiles">
                    { props.NavTiles.map((Tile: { Title: any; Icon: any; ComponentName: any; },index: any)=> <NavTileItem key={index} Title={Tile.Title} Icon={Tile.Icon} To={Tile.ComponentName} TopNavChange={props.TopNavChange.bind(this,Tile.ComponentName)}/> ) }
                </div>
            </div>
        </div>
    );
};

const mapStateToProps = (state) =>({
    NavTiles: state.NavTiles.MainNav,
    NavTitle: state.NavTiles.NavTitle,
    ActiveForm: state.FormData.ActiveForm,
    FormList: state.FormData.FormList
});

const mapDispatchToProps = (dispatch) => ({
    TopNavChange: (NavTitle: string) => dispatch(TopNavChange(NavTitle))
});

export default connect(mapStateToProps,mapDispatchToProps)(NavTile);