import * as React from 'react';

const FormNavTileItem = (props) => {
    return (
        <a href="#" className='tile' onClick={()=>console.log("Yes")} >
            <div className="icon">
                <i className='fa fa-file-word-o'></i>
            </div>
            <span className="title">{props.Title}</span>
        </a>
    );
}

export default FormNavTileItem;