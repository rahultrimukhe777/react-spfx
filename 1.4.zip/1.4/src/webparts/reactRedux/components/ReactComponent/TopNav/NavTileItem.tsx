import * as React from 'react';

const NavTileItem = (props) => {
    return (
        <div className='tile' onClick={props.TopNavChange } >
            <div className="icon">
                <i className={props.Icon}></i>
            </div>
            <span className="title">{props.Title}</span>
        </div>
    );
};

export default NavTileItem;