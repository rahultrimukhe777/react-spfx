export const TopNavChange = (NavTitle : string) =>({
    type: 'TOP_NAV_CHANGE',
    NavTitle
});