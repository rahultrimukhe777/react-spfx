import * as React from 'react';
import './__$Modal.css';

const Modal = (props) => {
	return (
		<div className="MyModal" style={{ position: "fixed", top: 0, left: 0, width: "100%", height: "100%", overflow: "auto", zIndex: 1, display: props.isModalOpen ? "block" : "none"}}>
			<div style={{ position: "fixed", top: 0, bottom: 0, left: 0, right: 0, width: "100%", height: "100%", backgroundColor: "rgba(0,0,0,0.5)" }} onClick={props.closeModal} />
			<div onClick={props.closeModal} />
			<div style={{ position: "relative", width: '70%', padding: 20, boxSizing: "border-box", backgroundColor: "#fff", margin: "80px auto", borderRadius: 3, zIndex: 2, textAlign: "left", boxShadow: "0 20px 30px rgba(0, 0, 0, 0.2)" }}>
				
                <h4 id="ModalTitle">{props.Title}</h4><hr/>
                {props.children} <hr/>
				<button className="btn btn-primary btn-sm" onClick={props.onSaveClick}>
					Save
				</button> &nbsp;
				<button className="btn btn-secondary btn-sm" onClick={props.onCloseClick}>
					Close
				</button>
			</div>
		</div>
	);
};

export default Modal;