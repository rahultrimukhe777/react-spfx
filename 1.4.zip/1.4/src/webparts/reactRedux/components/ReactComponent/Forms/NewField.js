import React from 'react';
import { connect } from 'react-redux';
import Input from './Input/Input'
import './__$NewField.css';

const getFilteredSubSection = (props,e) => {
    debugger;
};



class NewField extends React.Component {
    constructor(props){
        super(props);
        this.state={
            ActiveSection: 'Select',
            showOption: false,
            SubSectionList: [],
            NewOptions: ['one','Two','Three']
        },
        this.getFilteredSubSection = this.getFilteredSubSection.bind(this);
        this.addOptions = this.addOptions.bind(this);
    };
    getFilteredSubSection(ID,e) {
        if(ID==="SectionTitle" ) {
            this.state.SubSectionList = [...this.props.SubSectionList.map((x)=>x.SectionID===e.target.value && { ID:x.ID, Value: x.Title })].filter(x=>x);
            this.setState(()=>({ SubSectionList : this.state.SubSectionList }));
        } else if(ID==="FieldType" ) {
            if(e.target.value==='dropdown' || e.target.value==="checkbox") {
                this.setState({ showOption: true });
            } else {
                this.setState({ showOption: false });
            }
        } else {
            
        }
        
        console.log(this.state.SubSectionList);
    };
    removeOptions(value,e) {
        this.setState({ NewOptions: this.state.NewOptions.filter((x)=>x!==value)});
    }

    ChangeInput(index,e) {
        this.state.NewOptions[index] = e.target.value;
        this.setState({ NewOptions : this.state.NewOptions })
    }

    addOptions(value,e) {
        this.setState({ NewOptions: [...this.state.NewOptions,''] });
    }
    render() {
        let DropDownValues = undefined;
        return (
            <div className="row" style={{ padding: '10px' }}>
                {
                    this.props.NewFieldColumn.map((x)=>{
                        if(x.ID==="SectionTitle") {
                            DropDownValues = this.props.SectionList;
                        } else if(x.ID==="SubSectionTitle") {
                            DropDownValues = this.state.SubSectionList;
                        } else if(x.ID==="FieldType") {
                            DropDownValues = this.props.FieldType;
                        }
                        return (
                            <Input ChangeInput={ this.getFilteredSubSection.bind(this,x.ID) }  ID={x.ID && x.ID} Type={x.Type && x.Type} LabelText={x.LabelText && x.LabelText} LabelClass={x.LabelClass && x.LabelClass} DefaultValue={x.DefaultValue && x.DefaultValue} InputClass={x.InputClass && x.InputClass} PlaceHolder={x.PlaceHolder && x.PlaceHolder} Options={DropDownValues} DataList={x.DataList && x.DataList} InputStyle={x.InputStyle && x.InputStyle} SectionClass={x.SectionClass && x.SectionClass} />
                        )
                    })
                }
                {
                    this.state.showOption && 
                    <div className="col-12">
                        <h4 className="FieldLabel">Options</h4>
                        <hr/>
                        <a className="ActionButton AddNew" href="#" onClick={this.addOptions}><i className="fa fa-plus pl-1" aria-hidden="true"></i></a>
                    
                        <table className="table table-sm table-bordered OptionsTable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Options</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.NewOptions.map((x,index)=>{
                                        return (
                                            <tr>
                                                <th scope="row">{index+1}</th>
                                                <td className="Editable"><input value={x} onChange={this.ChangeInput.bind(this,index)} className="form-control"></input></td>
                                                <td><a href="#" className="ActionButton" onClick={this.removeOptions.bind(this,x)}><i className="fa fa-trash-o deleteOption" aria-hidden="true"></i></a></td>
                                            </tr>
                                        )
                                    })
                                }
                            </tbody>
                        </table>
                    </div>
                }
                
                <div className="col-12">
                    <h4 className="FieldLabel">Options</h4>
                    <ul id="Options">
                    {
                        this.state.NewOptions.map((x)=>{
                            return (
                                <div className="OptionsItem" ><li className="Options">{x}</li> <a className="remove" href="#" onClick={this.removeOptions.bind(this,x)}>x</a></div>
                            );
                        })
                    }
                    <div className="OptionsItemAdd"> <a className="AddNew" href="#" onClick={this.onMouseEnter}>Add +</a><input type="text" className="form-control" onBlur={this.onMouseOut} /></div>
                    </ul>
                </div>
            </div>   
        );
    }
};

const mapStateToProps = (state) =>({
    NavTiles: state.NavTiles,
    SectionList: state.FormData.SectionList.map((x)=>x.FormID===state.FormData.ActiveForm.ID && {ID: x.ID, Value: x.Title }).filter(item => item),
    SubSectionList: state.FormData.SubSectionList,
    FieldType: state.FormData.FieldType,
    NewFieldColumn: state.FormData.NewFieldColumn
});


export default connect(mapStateToProps)(NewField);