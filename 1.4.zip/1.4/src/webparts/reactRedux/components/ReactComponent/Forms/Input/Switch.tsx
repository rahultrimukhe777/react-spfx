import * as React from 'react';
import { connect } from 'react-redux';
import { formSwitchToggle } from '../FormsAction';
import './__$Switch.css';

var off = false;
const onOff = (e) => {
  var element = e.target.parentNode;
  off = !off;
  if(off) {
    element.className ="switch-off";
  } else {
    element.className ="switch";
  }
};

const Switch = (props) => {
    return (
        <a className={props.FormSwitch ? 'switch' : 'switch-off'}>
            <div className="dot" onClick={props.formSwitchToggle}></div>
            <div className="on-text">Horizontal</div>
            <div className="off-text">Vertical</div>
        </a>
    );
};

const mapStateToProps = (state) =>({
    FormSwitch: state.FormData.FormSwitch
});

const mapDispatchToProps = (dispatch) => ({
    formSwitchToggle: () => dispatch(formSwitchToggle())
});

export default connect(mapStateToProps,mapDispatchToProps)(Switch);