import * as React from 'react';
import { InputText, TextArea, InputFile, Select, CheckBox } from './InputChild';
import { InputLabel } from './InputLabel';
import { connect } from 'react-redux';
import './__$Input.css';

const SwitchCase = (props) =>{
    switch(props.Type.toLowerCase()) { 
        case 'text':
        case 'date':
        case 'time':
        case 'range':
        case 'number':
            return ( <InputText {...props}/> );
            break;
        case 'textarea':
            return ( <TextArea {...props}/> );
            break;
        case 'file':
            return (<InputFile />);
            break;
        case 'dropdown' :
            return (<Select {...props} />);
            break;
        case 'checkbox':
            return (<CheckBox {...props} />);
        default:
            debugger;
            return ( <div >No Input Found</div> );
            break; 
    }
};

const  Input = (props) => {
    return (
        props.InputStyle==="Horizontal" ?  <div className={`input-group mb-3 SubField ${props.SectionClass}`} >
            <a className="InputItemEdit"><i className="fa fa-trash-o pl-1" aria-hidden="true" ></i></a>
            { props.LabelText && <InputLabel LabelText={props.LabelText}/> }
            { SwitchCase(props) }
        </div> : <div className={`AddField SubField ${props.SectionClass}`}>
            <h4 className="FieldLabel">{props.LabelText}</h4>
            <a className="InputItemEdit"><i className="fa fa-trash-o pl-1" aria-hidden="true" ></i></a>
            { SwitchCase(props) }
            { props.DataList && <datalist id={props.DataList.Title}>
                    {
                        props.DataList.Options.map((x)=><option>{x}</option> )
                    }
                     
                </datalist> 
            }
        </div>
    );
};

export default connect(null,null)(Input);