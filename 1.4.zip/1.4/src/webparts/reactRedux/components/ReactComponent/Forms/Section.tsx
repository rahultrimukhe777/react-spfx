import * as React from 'react';
import { changeSection, deleteSection } from './FormsAction';
import { connect } from 'react-redux';
import './__$Section.css';

const Section = (props) => {
    return (
        <ul className="nav nav-tabs">
            {
                props.SectionList.map((x,index)=>{
                    return (
                        <li className="nav-item" key={index}>
                            <a className={`nav-link ${props.ActiveSection && props.ActiveSection.ID===x.ID ? 'active' : ''}`} href="#" >
                                <label onClick={props.changeSection.bind(this,x)}>{x.Title}</label>
                                <i className="fa fa-times" aria-hidden="true" onClick={props.deleteSection.bind(this,x.ID)}></i>
                            </a>
                        </li> 
                    );
                })
            }
        </ul>
    );
};

const mapStateToProps = (state) =>({
    ActiveSection: state.FormData.ActiveSection,
    SectionList: state.FormData.SectionList.filter((x)=>x.FormID===state.FormData.ActiveForm.ID)
});

const mapDispatchToProps = (dispatch) => ({
    changeSection: (ActiveSection) => dispatch(changeSection(ActiveSection)),
    deleteSection: (ID) => dispatch(deleteSection(ID))
});

export default connect(mapStateToProps,mapDispatchToProps)(Section);