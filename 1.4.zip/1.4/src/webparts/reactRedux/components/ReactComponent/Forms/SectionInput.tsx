import * as React from 'react';
import { connect } from 'react-redux';


const SectionInput = (props) => {
    return (
        <div className={`input-group mb-3 ${props.ID==="SubSectionTitle" ? 'Padding20' : ''}`}>
            <input type="text" className="form-control" id={props.ID} placeholder={props.PlaceHolder} aria-label="Enter new Section Title" aria-describedby="basic-addon2" />
            <div className="input-group-append" onClick={props.OnClick}>
                <span className="input-group-text" id="basic-addon2">{props.Title}</span>
            </div>
            <div className="input-group-append" onClick={props.OnCancelClick}>
                <span className="input-group-text" id="basic-addon2">Cancel</span>
            </div>
        </div>
    );
};

export default SectionInput;