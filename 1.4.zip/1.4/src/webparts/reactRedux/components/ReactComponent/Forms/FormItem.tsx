import * as React from 'react';
import { connect } from 'react-redux';
import { deleteFormById, editFormById, resetFormEditIndex, updateFormTitle, setActiveForm } from './FormsAction';
import { TopNavChange } from './../TopNav/TopNavActions';
import './__$FormItem.css';

const changeInput = (props,e) => {
    props.updateFormTitle(e.target.value,props.Index);
};

const FormItemBoxClicked = (props, e) => {
    props.TopNavChange('Form');
    props.setActiveForm({ID: props.ID, Title: props.Title});
    console.log(props,e);
};

const FormItem = (props) => {
    return (
        <div className="col-sm-3 cart">
            <div className="widget-chart widget-chart-hover">
                <div className="icon-wrapper rounded-circle">
                    <div className="icon-wrapper-bg bg-primary"></div>
                    <i className="fa fa-file-text-o" aria-hidden="true"></i>
                </div>
                <div className="widget-subheading">
                    {
                        props.EditFormIndex===props.ID ? 
                        <input type='text' onChange={changeInput.bind(this,props)} className="form-control EditTitle" value={props.Title}></input> : 
                        <a href='#' className='Formtile' onClick={FormItemBoxClicked.bind(this,props)} >
                            {props.Title}
                        </a>
                    }
                </div>
                <div className="widget-description text-success" >
                    <a onClick={props.deleteFormById.bind(this,props.ID)} className="ActionButton"> 
                        <i className="fa fa-trash-o pl-1" aria-hidden="true"></i>
                    </a>
                    {   
                        props.EditFormIndex!==props.ID ? 
                            <a onClick={props.editFormById.bind(this,props.ID)} className="ActionButton"> 
                                <i className="fa fa-pencil-square-o pl-1" aria-hidden="true"></i>
                            </a>
                        :
                            <a onClick={props.resetFormEditIndex} className="ActionButton"> 
                                <i className="fa fa-save pl-1" aria-hidden="true"></i>
                            </a> 
                    }
                </div> 
            </div>
        </div>
    );
};

const mapDispatchToProps = (dispatch) => ({
    deleteFormById: (ID) => dispatch(deleteFormById(ID)),
    editFormById: (ID) => dispatch(editFormById(ID)),
    resetFormEditIndex: () => dispatch(resetFormEditIndex()),
    updateFormTitle: (Title,Index) => dispatch(updateFormTitle(Title,Index)),
    setActiveForm: (ActiveForm) => dispatch(setActiveForm(ActiveForm)),
    TopNavChange: (NavTitle: string) => dispatch(TopNavChange(NavTitle))
});

const mapStateToProps = (state) => ({
    EditFormIndex: state.FormData.EditFormIndex
});

export default connect(mapStateToProps,mapDispatchToProps)(FormItem);