import * as React from 'react';
import { InputLabel } from './InputLabel';

export const InputText = (props) => {
    return (
        <input 
            type = {props.Type} 
            className = {props.InputClass} 
            id = {props.ID} 
            aria-describedby = "basic-addon3" 
            value = {props.DefaultValue && props.DefaultValue} 
            style = {{height: 'auto'}}
            onChange = {props.ChangeInput && props.ChangeInput}
            list={props.DataList && props.DataList.Title}
            placeholder = {props.PlaceHolder}
        />
    );
};

export const TextArea = (props) => {
    return ( 
        <textarea 
            className={props.InputClass} 
            defaultValue={props.DefaultValue} 
            aria-label="With textarea"
            onChange = {props.ChangeInput && props.ChangeInput}
        ></textarea> );
};

export const Select = (props) => {
    return (
        <select 
            className={props.InputClass && props.InputClass} 
            id={props.Id && props.Id } 
            defaultValue={ props.DefaultValue && props.DefaultValue}
            onChange = {props.ChangeInput && props.ChangeInput}
        >
            <option >Select</option>
            {  props.Options.map((x,index)=><option key={index} value={x.ID}>{x.Value}</option> )}
        </select>
    );
};

export const CheckBox = (props) => {
    return(
        <div className=" form-control" style={{ height: 'auto' }}>
            {  props.Options.map((x,index)=>
                <div className="custom-control custom-checkbox" key={index}>
                    <input 
                        type="checkbox" 
                        checked={props.DefaultValue.split(',').indexOf(x)>-1} 
                        className="custom-control-input" 
                        id={`${props.Id}${index}`} 
                        name={props.Id} 
                        onChange = {props.ChangeInput && props.ChangeInput}
                        title = {x} 
                    />
                    <label className="custom-control-label" htmlFor={`${props.Id}${index}`}>{x}</label>
                </div>
            )}
        </div>       
    );
};

const changeFileName = (e) => {
    let FileName = '';
    [...$(e.target)[0].files].map((x,index)=>{
        index===0 ? FileName = x.name : FileName = FileName + " || " + x.name;
    });
    $(e.target).siblings(".custom-file-label").addClass("selected").html(FileName);
};

export const InputFile = (props) => {
    return(
        <div className="custom-file">
            <input type="file" className="custom-file-input" multiple={true} onChange={changeFileName.bind(this)} id={props.Id} name="filename" />
            <label className="custom-file-label" htmlFor="customFile">Choose file</label>
        </div>
    );
};

