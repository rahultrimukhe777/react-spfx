// Delete form by ID
export const deleteFormById = (ID) =>({
    type: 'DELETE_FORM_BY_ID',
    ID
});

// Edit Form Title By Index
export const editFormById = (ID) => ({
    type: 'EDIT_FORM_BY_ID',
    ID
});

// Reset EditFormIndex
export const resetFormEditIndex = () => ({
    type: 'RESET_FORM_EDIT_INDEX'
});

// Update New Form Title
export const updateFormTitle = (Title,Index) => ({
    type: 'UPDATE_FORM_TITLE',
    Title,
    Index
});

// Add New Form
export const addNewForm = () => ({
    type: 'ADD_NEW_FORM'
});

// Set Active Form
export const setActiveForm = (ActiveForm={}) => ({
    type: 'SET_ACTIVE_FORM',
    ActiveForm
});

export const changeSection = (ActiveSection={}) => ({
    type: 'SET_ACTIVE_SECTION',
    ActiveSection
});

// Set Active SubSection
export const setActiveSubSection = (ActiveSubSection={}) => ({
    type: 'SET_ACTIVE_SUB_SECTION',
    ActiveSubSection
});

export const addNewSection = (NewSection={}) => ({
    type: 'ADD_NEW_SECTION',
    NewSection
});

export const addNewSubSection = (NewSubSection='') => ({
    type: 'ADD_NEW_SUB_SECTION',
    NewSubSection
});

export const deleteSection = (ID=-1) => ({
    type: 'DELETE_SECTION',
    ID
});

export const deleteSubSection = (ID=-1) => ({
    type: 'DELETE_SUB_SECTION',
    ID
});

export const addSectionBoxToggle = () => ({
    type: 'ADD_SECTION_BOX_TOGGLE'
});

export const addSubSectionBoxToggle = () => ({
    type: 'ADD_SUB_SECTION_BOX_TOGGLE'
});

export const addFieldBoxToggle = () => ({
    type: 'ADD_FIELD_BOX_TOGGLE'
});

export const onCancelClick = (target) => ({
    type:'ON_CANCEL_CLICK',
    target
});

export const onDragStart = (Item) => ({
    type: 'ON_DRAG_START',
    Item
});

export const onDragOver = (Item) => ({
    type: 'ON_DRAG_OVER',
    Item
});

export const onDragDrop = (Item) => ({
    type: 'ON_DRAG_DROP',
    Item
});

export const onDragDropEmpty = (SubSectionID) => ({
    type: 'ON_DRAG_DROP_EMPTY',
    SubSectionID
});

export const formSwitchToggle = () => ({
    type: 'FORM_SWITCH_TOGGLE'
});