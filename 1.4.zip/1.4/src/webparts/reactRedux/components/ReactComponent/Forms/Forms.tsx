import * as React from 'react';
import FormItemBox from './FormItemBox';
import './__$Forms.css';
import { connect } from 'react-redux';

const Forms = (props) => {
    return (
        <div className="container-fluid">
            <FormItemBox />
        </div>
    );
};

const mapStateToProps = (state) =>({
    NavTiles: state.NavTiles
});


export default connect(mapStateToProps)(Forms);