import * as React from 'react';
import { connect } from 'react-redux';
import { onDragStart, onDragDrop, onDragDropEmpty } from './FormsAction';
import Input from './Input/Input';
import './__$InputFields.css';

const InputFields = (props) => {
    const FilteredArray = props.SubSectionFields.filter((Field)=>Field.SubSectionID===props.SubSectionID);
        return (
            <div className="row" >
            { 
                FilteredArray.length>0 ? FilteredArray.map((Field,FieldIndex)=>{
                    return (
                    <div 
                        onDragOver={()=>console.log("Yes")}
                        onDrop={()=>console.log("Dropped")}
                        onDragStart = {props.onDragStart.bind(this, Field)}
                        onDragLeave = {props.onDragDrop.bind(this,Field)} 
                        draggable 
                        className={`${Field.SectionClass} DottedBorder`}
                    >
                        <Input 
                            Type={ Field.Type && Field.Type } 
                            LabelText={ Field.LabelText && Field.LabelText } 
                            LabelClass={ Field.LabelClass && Field.LabelClass } 
                            InputClass={ Field.InputClass && Field.InputClass }
                            Options={ Field.Options && Field.Options }
                            Id={ Field.ID && Field.ID }
                            key={FieldIndex}
                            InputStyle={ props.FormSwitch ? "Verticle" : "Horizontal" }
                        ></Input> 
                    </div>
                    )
                }) :  <div 
                        onDragLeave = {props.onDragDropEmpty.bind(this, props.SubSectionID)} 
                        draggable 
                        className="blankDragable"
                    ></div>
            }
        </div>
    );
};

const mapStateToProps = (state) =>({
    SubSectionFields: state.FormData.ActiveSection.ID ? state.FormData.SubSectionFields : [],
    FormSwitch: state.FormData.FormSwitch
});

const mapDispatchToProps = (dispatch) => ({
    onDragStart: (Item) => dispatch(onDragStart(Item)),
    onDragDrop: (Item) => dispatch(onDragDrop(Item)),
    onDragDropEmpty: (SubSectionId) => dispatch(onDragDropEmpty(SubSectionId))
});

export default connect(mapStateToProps,mapDispatchToProps)(InputFields);