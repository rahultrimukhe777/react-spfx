import * as React from 'react';
import { connect } from 'react-redux';
import { addNewForm, deleteSubSection, onCancelClick, addFieldBoxToggle } from './FormsAction';
import InputFields from './InputFields';
import Modal from './../Modal/Modal';
import './__$SubSection.css';

const SubSection = (props) => {
    return (
        <div>
            { 
                props.SubSectionList.map((x,index)=>{
                    return (
                        <div className="SubSection" id={x.ID} key={index}>
                            <h4 style={{ float: 'left' }} className="SubSectionHeader">{x.Title}</h4>
                            <a style={{ float: 'right' }} onClick={ props.deleteSubSection.bind(this, x.ID)} className="ActionButton"> 
                                <i className="fa fa-trash-o pl-1" aria-hidden="true"></i>
                            </a>
                            <a className="ActionButton" style={{float : 'right'}} onClick={ props.addFieldBoxToggle }>
                                <i className="fa fa-plus pl-1" aria-hidden="true"></i>
                            </a>
                            <hr style={{ clear: 'both' }}/>
                            <div className="container ">
                                <InputFields SubSectionID={x.ID}/>
                            </div>
                            
                        </div>
                    );
                })
            }
            {
                props.AddField && 
                <Modal Title="New Subsection Field" isModalOpen={true} onCloseClick={props.onCancelClick.bind(this,'Field')}>
                    
                </Modal>
            }
        </div>
    );
};

const mapStateToProps = (state) =>({
    SubSectionList: state.FormData.ActiveSection.ID ? state.FormData.SubSectionList.filter((x)=>x.SectionID===state.FormData.ActiveSection.ID) : [],
    AddField: state.FormData.AddField
});

const mapDispatchToProps = (dispatch) => ({
    addNewForm: () => dispatch(addNewForm()),
    deleteSubSection: (ID) => dispatch(deleteSubSection(ID)),
    onCancelClick: (Target) => dispatch(onCancelClick(Target)),
    addFieldBoxToggle: () => dispatch(addFieldBoxToggle())
});

export default connect(mapStateToProps,mapDispatchToProps)(SubSection);