import * as React from 'react';
import { connect } from 'react-redux';
import FormItem from './FormItem';
import { addNewForm } from './FormsAction';
import './__$FormBoxItem.css';

const FormItemBox = (props) => {
    return (
        <div className="no-gutters row">
            { props.FormData.map((Item,Index)=> <FormItem {...Item} Index={Index} key={Index}/> ) }
            <div className="col-sm-3 cart" onClick={props.addNewForm}>
                <div className="widget-chart widget-chart-hover">
                    <div className="icon-wrapper rounded-circle">
                        <div className="icon-wrapper-bg bg-primary"></div>
                        <i className="fa fa-plus" aria-hidden="true"></i>
                    </div>
                    <div className="widget-subheading" style={{ marginTop : '25.5px' }}> New Form </div>
                </div>
            </div>
        </div>
    );
};

const mapStateToProps = (state) =>({
    FormData: state.FormData.FormList
});

const mapDispatchToProps = (dispatch) => ({
    addNewForm: () => dispatch(addNewForm())
});

export default connect(mapStateToProps,mapDispatchToProps)(FormItemBox);