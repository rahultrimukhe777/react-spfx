import * as React from 'react';
import './__$Form.css';
import { connect } from 'react-redux';
import Switch from './Input/Switch';
import Input from './Input/Input';
import NewSection from './NewSection';

const Form = (props) => {
    return (
        <div className="container-fluid">
            <div id="FromContainer">
                <h2 className="FormTitle">{props.ActiveForm.Title && props.ActiveForm.Title}</h2>
                <Switch/>
                <NewSection />
                <div className="row SectionField">
                {
                    props.SubSectionFields.map((Field,FieldIndex)=>{
                        return (
                            
                            <Input 
                                Type={ Field.Type && Field.Type } 
                                LabelText={ Field.LabelText && Field.LabelText } 
                                LabelClass={ Field.LabelClass && Field.LabelClass } 
                                InputClass={ Field.InputClass && Field.InputClass }
                                Options={ Field.Options && Field.Options }
                                Id={ Field.Id && Field.Id }
                                SectionClass={Field.SectionClass && Field.SectionClass}
                                key={FieldIndex}
                            ></Input>
                            
                        );
                    })
                }
                </div>
            </div>
        </div>
    );
};

const mapStateToProps = (state) =>({
    ActiveForm: state.FormData.ActiveForm,
    SubSectionFields: state.FormData.SubSectionFields.filter((x)=>x.SubSectionID===state.FormData.ActiveSection.ID)
});

export default connect(mapStateToProps)(Form);