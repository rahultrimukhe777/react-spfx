import * as React from 'react';

export const InputLabel = (props) => {
    return (
        <div className="input-group-prepend">
            <span className="input-group-text" id="basic-addon3" >
                { props.LabelText }
            </span>
        </div> 
    );
}