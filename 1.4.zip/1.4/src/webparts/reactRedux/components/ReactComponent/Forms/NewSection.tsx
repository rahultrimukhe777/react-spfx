import * as React from 'react';
import Section from './Section';
import { connect } from 'react-redux';
import { addNewSection, addSectionBoxToggle, addSubSectionBoxToggle, onCancelClick, addNewSubSection } from './FormsAction';
import SubSection from './SubSection';
import Modal from './../Modal/Modal';

const AddNewSection = (props,e) => {
    // props.addNewSection(document.getElementById('SectionTitle').value);
};

const AddNewSubSection = (props,e) => {
    // props.addNewSubSection(document.getElementById('SubSectionTitle').value);
};

const NewSection = (props) => {
    return (
        <div className="AddNewSection">
            <a href='/Forms' className='tile SectionButton btn btn-primary btn-sm' onClick={()=>console.log("Yes")} >
                Back
            </a> 
            <a href='#' className={`tile SectionButton btn btn-primary btn-sm ${props.AddSectionBoxHidden ? 'disabled' : ''}`} onClick={props.addSectionBoxToggle} data-toggle="modal" data-target=".bd-example-modal-lg" >
                <i className="fa fa-plus" aria-hidden="true"></i> Section 
            </a>
            <a href='#' className={`tile SectionButton btn btn-primary btn-sm ${props.AddSubSectionBoxHidden ? 'disabled' : ''}`} onClick={props.addSubSectionBoxToggle} >
                <i className="fa fa-plus" aria-hidden="true"></i> Subsection 
            </a>
            {
                props.AddSectionBoxHidden &&
                <Modal Title="New Section" isModalOpen={true} onCloseClick={props.onCancelClick.bind(this,'Section')} onSaveClick={AddNewSection.bind(this,props)}>
                    <div className={`input-group mb-3 ${props.ID==="SubSectionTitle" ? 'Padding20' : ''}`}>
                        <input type="text" className="form-control" id='SectionTitle' placeholder="Enter new Section Title" aria-label="Enter new Section Title" aria-describedby="basic-addon2" />
                    </div>
                </Modal>       
            }
            <Section />
            {
                props.AddSubSectionBoxHidden &&
                <Modal Title="New Subsection" isModalOpen={true} onCloseClick={props.onCancelClick.bind(this,'SubSection')} onSaveClick={AddNewSubSection.bind(this,props)}>
                    <div className={`input-group mb-3 ${props.ID==="SubSectionTitle" ? 'Padding20' : ''}`}>
                        <input type="text" className="form-control" id='SubSectionTitle' placeholder="Enter new Subsection Title" aria-label="Enter new Subsection Title" aria-describedby="basic-addon2" />
                    </div>
                </Modal>   
            }
            <SubSection />
        </div>
    );
};

const mapStateToProps = (state) => ({
    SubSectionList: state.FormData.ActiveSection.ID ? state.FormData.SubSectionList.filter((x)=>x.SectionID===state.FormData.ActiveSection.ID) : [],
    AddSectionBoxHidden: state.FormData.AddSectionBoxHidden,
    AddSubSectionBoxHidden: state.FormData.AddSubSectionBoxHidden
});

const mapDispatchToProps = (dispatch) => ({
    addNewSection: (NewSectionTitle) => dispatch(addNewSection(NewSectionTitle)),
    addSectionBoxToggle: () => dispatch(addSectionBoxToggle()),
    addSubSectionBoxToggle: () => dispatch(addSubSectionBoxToggle()),
    onCancelClick: (Target) => dispatch(onCancelClick(Target)),
    addNewSubSection: (NewSubSection) => dispatch(addNewSubSection(NewSubSection))
});

export default connect(mapStateToProps,mapDispatchToProps)(NewSection);