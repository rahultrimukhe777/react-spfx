/* tslint:disable */
require("./Paging.module.css");
const styles = {
  paginationContainer: 'paginationContainer_ec87d8f3',
  searchWp__paginationContainer__pagination: 'searchWp__paginationContainer__pagination_ec87d8f3',
  active: 'active_ec87d8f3'
};

export default styles;
/* tslint:enable */