import * as React from 'react';
import NavTile from './ReactComponent/TopNav/NavTile';
import { SPComponentLoader } from '@microsoft/sp-loader';
import * as $ from 'jquery';


export default class Container extends React.Component {
    public constructor(props) {
      super(props);
      SPComponentLoader.loadCss('https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css');
      SPComponentLoader.loadCss('https://netdna.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css');
    }
    public componentDidMount(){
        $('#navbox-trigger').click(function () {
            return $('#navigation-bar').toggleClass('navbox-open');
        });
        return $(document).on('click', function (e) {
            var $target;
            $target = $(e.target);
            if (!$target.closest('.navbox').length && !$target.closest('#navbox-trigger').length) {
                return $('#navigation-bar').removeClass('navbox-open');
            }
        });
    }

    public render(): React.ReactElement<{}> {
      return (
        <div >
            <div className="wrapper">
                <NavTile/>
                <div id="content" className="container-fluid">
                    {this.props.children}
                </div>
            </div>
        </div>
      );
    }
}
