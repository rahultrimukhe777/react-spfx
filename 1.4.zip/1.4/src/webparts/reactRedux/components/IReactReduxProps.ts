export interface IReactReduxProps {
  description: string;
}
