import './__$Form.css';
declare const _default: any;
export default _default;
//# sourceMappingURL=Form.d.ts.map