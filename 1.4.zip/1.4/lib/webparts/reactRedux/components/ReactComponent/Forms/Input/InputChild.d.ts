/// <reference types="react" />
export declare const InputText: (props: any) => JSX.Element;
export declare const TextArea: (props: any) => JSX.Element;
export declare const Select: (props: any) => JSX.Element;
export declare const CheckBox: (props: any) => JSX.Element;
export declare const InputFile: (props: any) => JSX.Element;
//# sourceMappingURL=InputChild.d.ts.map