import './__$Switch.css';
declare const _default: any;
export default _default;
//# sourceMappingURL=Switch.d.ts.map