import './__$InputFields.css';
declare const _default: any;
export default _default;
//# sourceMappingURL=InputFields.d.ts.map