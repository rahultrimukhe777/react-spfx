export declare const deleteFormById: (ID: any) => {
    type: string;
    ID: any;
};
export declare const editFormById: (ID: any) => {
    type: string;
    ID: any;
};
export declare const resetFormEditIndex: () => {
    type: string;
};
export declare const updateFormTitle: (Title: any, Index: any) => {
    type: string;
    Title: any;
    Index: any;
};
export declare const addNewForm: () => {
    type: string;
};
export declare const setActiveForm: (ActiveForm?: {}) => {
    type: string;
    ActiveForm: {};
};
export declare const changeSection: (ActiveSection?: {}) => {
    type: string;
    ActiveSection: {};
};
export declare const setActiveSubSection: (ActiveSubSection?: {}) => {
    type: string;
    ActiveSubSection: {};
};
export declare const addNewSection: (NewSection?: {}) => {
    type: string;
    NewSection: {};
};
export declare const addNewSubSection: (NewSubSection?: string) => {
    type: string;
    NewSubSection: string;
};
export declare const deleteSection: (ID?: number) => {
    type: string;
    ID: number;
};
export declare const deleteSubSection: (ID?: number) => {
    type: string;
    ID: number;
};
export declare const addSectionBoxToggle: () => {
    type: string;
};
export declare const addSubSectionBoxToggle: () => {
    type: string;
};
export declare const addFieldBoxToggle: () => {
    type: string;
};
export declare const onCancelClick: (target: any) => {
    type: string;
    target: any;
};
export declare const onDragStart: (Item: any) => {
    type: string;
    Item: any;
};
export declare const onDragOver: (Item: any) => {
    type: string;
    Item: any;
};
export declare const onDragDrop: (Item: any) => {
    type: string;
    Item: any;
};
export declare const onDragDropEmpty: (SubSectionID: any) => {
    type: string;
    SubSectionID: any;
};
export declare const formSwitchToggle: () => {
    type: string;
};
//# sourceMappingURL=FormsAction.d.ts.map