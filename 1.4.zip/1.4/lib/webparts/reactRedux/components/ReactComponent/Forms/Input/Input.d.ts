import './__$Input.css';
declare const _default: any;
export default _default;
//# sourceMappingURL=Input.d.ts.map