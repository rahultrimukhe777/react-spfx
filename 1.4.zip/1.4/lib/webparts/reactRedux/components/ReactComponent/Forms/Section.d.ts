import './__$Section.css';
declare const _default: any;
export default _default;
//# sourceMappingURL=Section.d.ts.map