/// <reference types="react" />
export declare const InputLabel: (props: any) => JSX.Element;
//# sourceMappingURL=InputLabel.d.ts.map