import './__$SubSection.css';
declare const _default: any;
export default _default;
//# sourceMappingURL=SubSection.d.ts.map