/// <reference types="react" />
import './__$Modal.css';
declare const Modal: (props: any) => JSX.Element;
export default Modal;
//# sourceMappingURL=Modal.d.ts.map