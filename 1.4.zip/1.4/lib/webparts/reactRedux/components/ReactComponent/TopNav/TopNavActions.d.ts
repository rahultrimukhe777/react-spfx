export declare const TopNavChange: (NavTitle: string) => {
    type: string;
    NavTitle: string;
};
//# sourceMappingURL=TopNavActions.d.ts.map