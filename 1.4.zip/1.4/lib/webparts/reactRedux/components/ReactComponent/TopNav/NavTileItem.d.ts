/// <reference types="react" />
declare const NavTileItem: (props: any) => JSX.Element;
export default NavTileItem;
//# sourceMappingURL=NavTileItem.d.ts.map