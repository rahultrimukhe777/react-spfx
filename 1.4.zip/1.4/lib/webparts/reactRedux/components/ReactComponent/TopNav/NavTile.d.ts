import './__$NavTile.css';
declare const _default: any;
export default _default;
//# sourceMappingURL=NavTile.d.ts.map