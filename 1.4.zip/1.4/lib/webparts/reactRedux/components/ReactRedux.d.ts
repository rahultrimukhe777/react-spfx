import * as React from 'react';
import { IReactReduxProps } from './IReactReduxProps';
export default class ReactRedux extends React.Component<IReactReduxProps, {}> {
    private states;
    componentDidMount(): void;
    render(): React.ReactElement<IReactReduxProps>;
}
//# sourceMappingURL=ReactRedux.d.ts.map