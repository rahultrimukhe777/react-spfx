export interface IReactReduxProps {
    description: string;
}
//# sourceMappingURL=IReactReduxProps.d.ts.map