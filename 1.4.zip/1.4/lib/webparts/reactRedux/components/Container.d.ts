import * as React from 'react';
export default class Container extends React.Component {
    constructor(props: any);
    componentDidMount(): JQuery<Document>;
    render(): React.ReactElement<{}>;
}
//# sourceMappingURL=Container.d.ts.map