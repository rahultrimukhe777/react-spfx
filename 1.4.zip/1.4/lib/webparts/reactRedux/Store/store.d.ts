declare const _default: () => import("../../../../../../../../../../Users/rtrim/OneDrive/Desktop/SPFX/React-Redux/node_modules/redux").Store<{
    NavTiles: {
        NavTitle: any;
        MainNav: {
            Title: string;
            Icon: string;
            ComponentName: string;
        }[];
    };
    FormData: any;
}, import("../../../../../../../../../../Users/rtrim/OneDrive/Desktop/SPFX/React-Redux/node_modules/redux").AnyAction> & {
    dispatch: {};
};
export default _default;
//# sourceMappingURL=store.d.ts.map