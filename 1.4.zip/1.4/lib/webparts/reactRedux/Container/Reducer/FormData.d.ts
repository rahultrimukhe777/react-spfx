declare const _default: (state: any, action: any) => any;
export default _default;
//# sourceMappingURL=FormData.d.ts.map