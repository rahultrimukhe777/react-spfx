declare const _default: (state: {
    MainNav: {
        Title: string;
        Icon: string;
        ComponentName: string;
    }[];
    NavTitle: string;
}, action: any) => {
    NavTitle: any;
    MainNav: {
        Title: string;
        Icon: string;
        ComponentName: string;
    }[];
};
export default _default;
//# sourceMappingURL=TopNavTile.d.ts.map